<?php 
        $db = mysql_connect('mysql.hostinger.com.br', 'u445301973_admin', 'b1b2b3b4') or die('Could not connect: ' . mysql_error()); 
        mysql_select_db('u445301973_unity') or die('Could not select database');

        // Strings must be escaped to prevent SQL injection attack. 
        $name = mysql_real_escape_string($_GET['name'], $db); 
echo $name;
        $score = mysql_real_escape_string($_GET['score'], $db); 
echo $score;
        $hash = $_GET['hash']; 
echo  $hash;
        $secretKey="z"; 
echo $secretKey;
        /* $real_hash = $name . $score . $secretKey; */

$real_hash = $secretKey;

        if($real_hash == $hash) { 
            // Send variables for the MySQL database class. 
            $query = "insert into scores (name, score) values ('$name' , $score);"; 
            $result = mysql_query($query) or die('Query failed: ' . mysql_error()); 
        } 
?>