-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 12/11/2013 às 11h59min
-- Versão do Servidor: 5.5.16
-- Versão do PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `cake`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `ranks`
--

CREATE TABLE IF NOT EXISTS `ranks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `texto` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `score` int(11) NOT NULL,
  `posicion` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `ranks`
--

INSERT INTO `ranks` (`id`, `nome`, `texto`, `created`, `modified`, `score`, `posicion`) VALUES
(5, 'Fucker', 'aaaaaaaaaaaaaaaaaaa', '2013-11-11 00:55:42', '2013-11-12 10:42:15', 22, 3),
(6, 'p1', 'aaaaaaaaaaaaa', '2013-11-12 10:42:53', '2013-11-12 10:42:53', 222, 1),
(7, 'ssss', 'sssssssssssssssssssssssssssss', '2013-11-12 10:42:59', '2013-11-12 10:44:15', 33, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
