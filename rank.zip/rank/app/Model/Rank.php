<?php

class Rank extends AppModel{

	public $name = 'Rank';
	var $useTable = false;  

   public function getRanks() 
    {
	
		return($this->query("
		SELECT escore, nome, FIND_IN_SET(
                escore,  (SELECT  GROUP_CONCAT(
                            DISTINCT escore
                            ORDER BY escore  DESC
                        )
                FROM    ranks)
            ) as posi
        FROM   ranks
		ORDER BY escore DESC;")); 
		
    }
}
?>