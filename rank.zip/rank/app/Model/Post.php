<?php

class Post extends AppModel{
	
	public $name = 'Post';
	
}
?>