<?php
class RanksController extends AppController{
	var $uses = array("Ranks");
	public $name = 'Ranks';
	
	public function index(){
		$this->loadModel('Rank');
        $this->set('dados',$this->Rank->getRanks());
	}
	
	
}
?>