<?php
include_once("controleProdutos.php");

 $produtos = mostrarProdutos();

$xml = '<?xml version="1.0" encoding="ISO-8859-1"?>';
 
$xml .= '<produtos>';
 
if ($produtos->num_rows > 0) {
	while($temp = $produtos->fetch_assoc()) {
	$xml .= '<produto>';
	$xml .= '<quantidade>' . $temp['quantidade'] . '</quantidade>';
	$xml .= '<categoria>' . $temp['categoria'] . '</categoria>';
	$xml .= '<lote>' . $temp['lote'] . '</lote>';	
	$xml .= '<valor>' . $temp['valor'] . '</valor>';
	$xml .= '<descricao>' . $temp['descricao'] . '</descricao>';
	$xml .= '</produto>';
    }
}
 
$xml .= '</produtos>';
 
$arquivo = fopen('produtos.xml', 'w+');
fwrite($arquivo, $xml);
fclose($arquivo);
header("location: index.php");

?>