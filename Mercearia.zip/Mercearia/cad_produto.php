<?php
include_once("controleProdutos.php");
include_once('header.inc');



if (!empty($_POST)) {

    extract($_POST);
    inserirProduto($categoria, $quantidade, $lote, $descricao, $valor);
}
?>

<form method="post" action="cad_produto.php"
      name="cad_produto">

    <label>categoria</label>
    <input type="text" class="form-control"  name="categoria" placeholder="carne, legumes, enlatados, etc.">
    <label>quantidade</label>
    <input type="text" class="form-control"  name="quantidade">
    <label>lote</label>
    <input type="text" class="form-control"  name="lote">
    <label>valor</label>
    <input type="text" class="form-control"  name="valor" placeholder="use ponto e não vírgula">
    <label>descrição</label>
    <textarea class="form-control" rows="3" name="descricao"></textarea>

    <button type="submit" class="btn btn-default"  > Cadastrar </button>

</form>
<?php
include_once("footer.inc");
?>

