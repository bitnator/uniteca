<?php
include_once('header.inc');
?>

<div class="jumbotron">
    <div class="container">
        <h1> XML  </h1>
        <p>Você pode importar e exportar dados para xml e também enviar relatorio por e-mail</p>
        <p><a class="btn btn-primary btn-lg" href="xmlimport.php" role="button">importar arquivo produtos.xml &raquo;</a></p>
        <p><a class="btn btn-primary btn-lg" href="xmlexport.php" role="button">exportar arquivo produtos.xml &raquo;</a></p>
        <p><a class="btn btn-primary btn-lg" href="relatorio.php" role="button">enviar relatório por e-mail &raquo;</a></p>
    </div>
</div>

<?php
include_once("footer.inc");
?>