<?php

include_once("conexao.php");

//controleProdutos
function inserirLote($distribuidor) {
    $conexao = conectar();
    $sql = "insert into lotes (distribuidor) values ('$distribuidor');";
    $conexao->query($sql);
    $conexao->close();
    echo "cadastrado com sucesso!";
}

function mostrarLotes() {
    $conexao = conectar();
    $sql = "SELECT * FROM lotes";
    $tabela = $conexao->query($sql);
    $conexao->close();
    return $tabela;
}

function alterarLote($id, $distribuidor) {
    $conexao = conectar();
    $sql = "update lotes set distribuidor ='$distribuidor' where id = $id ;";
    $conexao->query($sql);
    $conexao->close();
}

function excluirLote($codigo) {
    $conexao = conectar();
    $sql = "DELETE FROM `lotes` WHERE `lotes`.`id` = " . $codigo;
    $conexao->query($sql);

    $conexao->close();
}

?>