<?php
include_once("controleLotes.php");
include_once('header.inc');
?>

<table class="table">
    <tr>
        <td class="active">id</td>
        <td class="active">distribuidor</td>
        <td class="active"></td>
    </tr>

    <?php
    $Lotes = mostrarLotes();

    if ($Lotes->num_rows > 0) {
        // output data of each temp
        while ($temp = $Lotes->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $temp["id"] . " </td><td>" . $temp["distribuidor"] . "</td>";
//imprimir ações editar e excluir
            echo "<td><a class= \"btn btn-success \" role= \" button \"  href=\" alter_lote.php?id=" . $temp["id"] . " \"> editar </a> <a  class= \" btn btn-danger \" role= \"button \"  href=\" excluir_lote.php?excluir=" . $temp["id"] . " \"> excluir </a> </td>";

            echo "</tr>";
        }
    } else {
        echo "0 r";
    }
    ?>

</table>

<?php
include_once("footer.inc");
?>