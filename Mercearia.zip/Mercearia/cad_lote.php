<?php
include_once("controleLotes.php");
include_once('header.inc');

$conexao = conectar();
if (!empty($_POST)) {

    extract($_POST);
    inserirLote($distribuidor);
}
?>

<br>
<form method="post" action="cad_lote.php"
      name="cad_lote">

    <label>distribuidor</label>
    <input type="text" class="form-control"  name="distribuidor">

    <button type="submit" class="btn btn-default"> Cadastrar </button>
</form>

<?php
include_once("footer.inc");
?>

