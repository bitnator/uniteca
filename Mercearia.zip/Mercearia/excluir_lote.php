<?php

include_once("controleLotes.php");

excluirLote($_GET['excluir']);
header("location: listar_lotes.php");
?>