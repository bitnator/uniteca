<?php

include_once("controleProdutos.php");

excluirProduto($_GET['cod_barras']);

header("location: listar_produtos.php");
?>