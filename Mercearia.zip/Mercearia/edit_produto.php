<?php

include_once("controleProdutos.php");


if (!empty($_POST)) {

    extract($_POST);
    alterarProduto($categoria, $quantidade, $lote, $descricao, $cod_barras, $valor);

    header("location: listar_produtos.php");
}
?>
