<?php
echo "não implementado";
/*
não é possíbel enviar emails via localhost
*/
?>