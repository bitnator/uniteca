<?php
include_once('header.inc');
?>
<form method="post" action="edit_lote.php"
      name="alter_lote">alterar lote<br>
    <br>
    <input name="id" type="hidden" value="<?php echo $_GET['id']; ?>">
    <label>distribuidor</label>
    <input type="text" class="form-control"  name="distribuidor">

    <button type="submit" class="btn btn-default"> Alterar </button>
</form>
<?php
include_once("footer.inc");
?>


