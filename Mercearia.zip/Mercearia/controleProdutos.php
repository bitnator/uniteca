<?php

include_once("conexao.php");

//controleProdutos
function inserirProduto($categoria, $quantidade, $lote, $descricao, $valor) {
    $conexao = conectar();
    $sql = "insert into produtos (quantidade, categoria, lote, descricao , valor) values ('$quantidade','$categoria','$lote','$descricao','$valor');";
    $conexao->query($sql);
    echo "cadastrado com sucesso!";
    $conexao->close();
}

function mostrarProdutos() {
    $conexao = conectar();
    $sql = "SELECT * FROM produtos";
    $tabela = $conexao->query($sql);
    return $tabela;
}

function alterarProduto($categoria, $quantidade, $lote, $descricao, $cod_barras, $valor) {
    $conexao = conectar();
    $sql = "update produtos set categoria ='$categoria', quantidade ='$quantidade', lote ='$lote', descricao ='$descricao', valor = '$valor' where cod_barras = $cod_barras ;";
    $conexao->query($sql);
    $conexao->close();
}

function excluirProduto($barras) {
    $conexao = conectar();
    $sql = "DELETE FROM `produtos` WHERE `produtos`.`cod_barras` = " . $barras;
    $conexao->query($sql);

    $conexao->close();
}

?>