
<?php

include_once("controleLotes.php");

if (!empty($_POST)) {

    extract($_POST);
    alterarLote($id, $distribuidor);
    header("location: listar_lotes.php");
}
?>