<?php
include_once("controleProdutos.php");
include_once("header.inc");
?>

<table class="table">
    <tr>
        <td class="active">codigo</td>
        <td class="active">categoria</td>
        <td class="active">quantidade</td>
        <td class="active">lote</td>
        <td class="active">valor $ (em reais)</td>
        <td class="active">descrição</td>
        <td class="active"></td>
    <tr>

        <?php
        $produtos = mostrarProdutos();

        if ($produtos->num_rows > 0) {
            while ($row = $produtos->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["cod_barras"] . " </td>";
                echo "<td>" . $row["categoria"] . "</td>";
                echo "<td>" . $row["quantidade"] . "</td>";
                echo "<td>" . $row["lote"] . "</td>";
                echo "<td>" . $row["valor"] . "</td>";
                echo "<td>" . $row["descricao"] . "</td>";
                //imprimir ações editar e excluir
                echo "<td><a class= \"btn btn-success \" role= \" button \"  href=\" alter_produto.php?cod_barras=" . $row["cod_barras"] . " \"> editar </a> <a  class= \" btn btn-danger \" role= \"button \"  href=\" excluir_produto.php?cod_barras=" . $row["cod_barras"] . " \"> excluir </a> </td>";
                echo "</tr>";
            }
        } else {
            echo "0 results";
        }
        ?>

</table>
        <?php
        include_once("footer.inc");
        ?>