<?php
include_once("controleProdutos.php");

$arquivo_xml = simplexml_load_file('produtos.xml');
 
for ( $i = 0; $i < count( $arquivo_xml ); $i++ ) {

	$quantidade = $arquivo_xml->produto[$i]->quantidade;
	$categoria = $arquivo_xml->produto[$i]->categoria;
	$lote = $arquivo_xml->produto[$i]->lote;
	$valor = $arquivo_xml->produto[$i]->valor;
	$descricao = $arquivo_xml->produto[$i]->descricao;

	inserirProduto($categoria,$quantidade,$lote,$descricao,$valor);

	echo '<hr>';
}

header("location: index.php");


?>