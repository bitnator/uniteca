<?php

// Connect to a single db
function conectar() {
    $username = "root";
    $password = "";
    $hostname = "localhost";
    $dbname = "mercearia";
    // Create connection
    $conn = new mysqli($hostname, $username, $password, $dbname);

// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
//echo "Conctado!";
    return $conn;
}

?>