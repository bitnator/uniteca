<?php
require_once("src/codebird.php");

\Codebird\Codebird::setConsumerKey("BbgAt3vvt274LsF3o7tF8JIhV","0OzZb2CujNWNba3GlN46a1rIGjVTl4tjXHnEMXFsBDaLxf7Wx1");
$test = \Codebird\Codebird::getInstance();
$test->setToken("4632347176-1K8u6ElC6fop7FuC4KzJWF97ouaOg33AcUP9vuC","g8F9vztws7UyLnT8DvqCOdIX7pbMEWragrP283YtBxM1V");

//declaração dos arrays para os testes
$friends = array();
$followers = array();
$unf = array();

$n_cursor = 1;
$n_c2 = 1;
$i = 0;
$j = 0;
//começa agora a parte que conta as meus followins

$follow = $test->friends_list(['count' => 200]);
//print_r($follow);


while ($n_cursor != 0) {

    foreach ($follow->users as $reply) {
        /*
        echo $reply->screen_name;
        echo " - ";
        */
        $friends[] = $reply->screen_name;
        $i++;
        
    }
    /*
    echo $i;
    echo " -  ";
    echo $follow->next_cursor;
    */
    $n_cursor = $follow->next_cursor;
    if ($n_cursor != 0) {
        $follow = $test->friends_list(['count' => 200, 'cursor' => $n_cursor]);
    }

}
//fim do getfollows

//print_r($replies);
//echo $reply;

//inicio do getfollowers
$followerslist = $test->followers_list(['count' => 200]);

while($n_c2 != 0) {
    foreach ($followerslist->users as $follower) {
        $followers[] = $follower->screen_name;
        $j++;
    }
    $n_c2 = $followerslist->next_cursor;
    if ($n_c2 != 0) {
        $followerslist = $test->followers_list(['count' => 200 , 'cursor' => $n_c2]);
    }
}
//fim do getfollowers
//print_r($followers);
//print_r($friends);

//inicio da verificação de quem nao me segue mas eu sigo
$unf = array_diff($friends, $followers);
//fim da verificação dos unfollowers
//print_r($unf);
//parte que da unfollow na negada
foreach ($unf as $target) {
    $log = $test->friendships_destroy(['screen_name' => $target]);
    echo "fuck you";
}

