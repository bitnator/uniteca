<?php

require_once ('src/codebird.php');
\Codebird\Codebird::setConsumerKey("BbgAt3vvt274LsF3o7tF8JIhV", "0OzZb2CujNWNba3GlN46a1rIGjVTl4tjXHnEMXFsBDaLxf7Wx1");
$cb = \Codebird\Codebird::getInstance();
$cb->setToken("4632347176-1K8u6ElC6fop7FuC4KzJWF97ouaOg33AcUP9vuC", "g8F9vztws7UyLnT8DvqCOdIX7pbMEWragrP283YtBxM1V");
 /*
$params = array(
  'status' => 'the zoera never ends!! vortey'
);
$reply = $cb->statuses_update($params);
*/

$name = "Desejarei";

$reply = $cb->friendships_create(
	['screen_name' => $name]
);

