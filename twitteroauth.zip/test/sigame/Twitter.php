<?php
require_once ('codebird.php');

/* require 'vendor/autoload.php';

use Codebird\Codebird;
*/
class Twitter
{
    protected $consumer_key = <API_KEY>;
    protected $consumer_secret = <API_SECRET>;
    protected $access_token = <ACCESS_TOKEN>;
    protected $access_secret = <ACCESS_SECRET>;
    protected $twitter;

    public function __construct()
    {
        // Fetch new Twitter Instance
        Codebird::setConsumerKey($this->consumer_key, $this->consumer_secret);
        $this->twitter = Codebird::getInstance();

        // Set access token
        $this->twitter->setToken($this->access_token, $this->access_secret);
    }

    public function tweet($message)
    {
        return $this->twitter->statuses_update(['status' => $message]);
    }

}