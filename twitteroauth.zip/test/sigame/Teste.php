<?php
$vetor = array();
$vetor[] = "teste";
$vetor[] = "outrogato";
$vetor[] = "hellokity";
$vetor[] = "heisembeeg";

//print_r($vetor);

$vetor2 = array();
$vetor2[] = "teste";
$vetor2[] = "lalala";

//vetor_diff mostra o que tem no primeiro que nao tem no segundo argumento
$resultado = array_diff($vetor2,$vetor);
//$resultado = array_intersect($vetor,$vetor2);
print_r($resultado);

/*
require 'Twitter.php';

$twtr = new Twitter;

$twtr->tweet('Hello World!');
*/