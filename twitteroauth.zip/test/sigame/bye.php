<?php
require_once("src/codebird.php");

\Codebird\Codebird::setConsumerKey("BbgAt3vvt274LsF3o7tF8JIhV","0OzZb2CujNWNba3GlN46a1rIGjVTl4tjXHnEMXFsBDaLxf7Wx1");

$cb = \Codebird\Codebird::getInstance();
//acima cria uma instancia 
//abaixo muda o token
$cb->setToken("4632347176-1K8u6ElC6fop7FuC4KzJWF97ouaOg33AcUP9vuC","g8F9vztws7UyLnT8DvqCOdIX7pbMEWragrP283YtBxM1V");

$target = "desejarei";

$reply = $cb->friendships_destroy(['screen_name' => $target]);



