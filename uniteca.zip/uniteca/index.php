<?php
include ("funcs.php");
?>

<!DOCTYPE html>
<!--[if IE 9]><html class="lt-ie10" lang="en" > <![endif]-->
<html class="no-js" lang="en" >

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Foundation 5</title>

        <!-- If you are using CSS version, only link these 2 files, you may add app.css to use for your overrides if you like. -->
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/foundation.css">

        <!-- If you are using the gem version, you need this only -->
        <link rel="stylesheet" href="css/app.css">

        <script src="js/vendor/modernizr.js"></script>
        <style>
            .green{background-color:  lightgreen;}
            .blue{background-color:  blue;}
            .blue {color: white;}
        </style>

    </head>
    <body>
    <!-- menu -->

    <div class="row"> 
        <div class="large-12 columns"> 
            <nav class="top-bar" data-topbar> 
                <ul class="title-area">
                    <li class="name">
                        <h1><a href="#">Página inicial </a></h1>
                    </li> 
                    <!-- Remove the class "menu-icon" to get rid of menu icon. Take out "Menu" to just have icon alone --> 
                    <li class="toggle-topbar menu-icon">
                        <a href="#"><span>Menu</span>
                        </a>
                    </li> 
                </ul>
                <section class="top-bar-section"> 

                    <!-- Left Nav Section -->
                    <ul class="left"> 
                        <li>
                            <a href="registro.php">Registrar usuário ou retiradas</a>
                        </li> 

                    </ul>
                    <ul class="left"> 
                        <li><a href="listaralertas.php">Verificar pendências</a></li> 
                    </ul>
                </section>
            </nav>
        </div> 
    </div> 

    <!-- fim menu  e comeca paragraf -->
    </br>
    
    <div class="row">
        <div class="medium-12 columns green">
            <h1 class="subheader">Você póde  se registrar em "registrar usuário ou retirada"</h1>

        </div>
    </div>

    <!-- começa seg paragraf -->
     </br>

    <div class="row">            
        <div class="medium-12 columns green">
            <h2 class="subheader">Você também pode pesquisar registros em "Verificar Pendências"</h2>

        </div>

    </div>

    <!-- body content here -->


        <script src="js/vendor/jquery.js"></script>
        <script src="js/foundation.min.js"></script>
        <script>
            $(document).foundation();
        </script>
    </body>
</html>


