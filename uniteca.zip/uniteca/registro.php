
<?php
include ("funcs.php");

?>

<!DOCTYPE html>
<!--[if IE 9]><html class="lt-ie10" lang="en" > <![endif]-->
<html class="no-js" lang="en" >

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sistema de alertas</title>

        <!-- If you are using CSS version, only link these 2 files, you may add app.css to use for your overrides if you like. -->
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/foundation.css">

        <!-- If you are using the gem version, you need this only -->
        <link rel="stylesheet" href="css/app.css">

        <script src="js/vendor/modernizr.js"></script>
        <style>
            .green{background-color:  lightgreen;}
            .blue{background-color:  blue;}
            .blue {color: white;}
        </style>

    </head>
    <body>

        <div class="row"> 
            <div class="small-12 columns"> 
                <nav class="top-bar" data-topbar> 
                    <ul class="title-area">
                        <li class="name">
                            <h1><a href="index.php">Página inicial </a></h1>
                        </li> 
                        <!-- Remove the class "menu-icon" to get rid of menu icon. Take out "Menu" to just have icon alone --> 
                        <li class="toggle-topbar menu-icon">
                            <a href="#"><span>Menu</span>
                            </a>
                        </li> 
                    </ul>
                    <section class="top-bar-section"> 

                        <!-- Left Nav Section -->
                        <ul class="left"> 
                            <li class="active">
                                <a href=" ">Registrar usuário ou retiradas</a>
                            </li> 

                        </ul>
                        <ul class="left"> 
                            <li><a href="listaralertas.php">Verificar pendências</a></li> 
                        </ul>
                    </section>
                </nav>
            </div> 
        </div> 

        <div class="row">
            <div class="small-8 small-centered columns">
                <h1 class="subheader">Formulário de cadastro</h1>
                </div> 
        </div> 
         
        <div class="row">
            <div class="medium-8 small-centered columns green">
                <form  name="contatof" method="post" action=" "  data-abide>
                    <div class="row"> 
                        <div class="large-12 columns"> 
                            <label>
                                Nome: <input type="text" required pattern="[a-zA-Z]+"  name="nome" placeholder="digite seu nome completo!" />
                            </label>
                             <small class="error">Name is required and must be a string.</small>
                        </div> 
                    </div> 
                 
<div class="email-field">
    <label>Email  
      <input type="email"  name="email" placeholder="exemplo: astrogildo@exemplo.com " required>
    </label>
    <small class="error">An email address is required.</small>
  </div>
                    <div class="row"> 
                        <div class="large-12 columns"> 
                            <label>
                                Matrícula:  <input type="text" name="matricula" placeholder="Digite sua matricula da instituição" />
                            </label>
                        </div> 
                    </div> 


                    <div class="row"> 
                        <div class="large-12 columns">
                            <input type="submit"   name="ok" value="Cadastrar"/>

                        </div>
                    </div>

                    <div class="row"> 
                        <div class="large-12 columns">
                            <?php
                            if (isset($_POST['ok'])) {
                                $nome = filter_input(INPUT_POST, "nome", FILTER_SANITIZE_MAGIC_QUOTES);
                               // echo $nome;
                                $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_MAGIC_QUOTES);
                               // echo $email;
                                $matricula = filter_input(INPUT_POST, "matricula", FILTER_SANITIZE_MAGIC_QUOTES);
                                //echo $matricula;
                                cadUser($nome, $matricula, $email);
                            }// fim isset
                            ?>
                        </div>
                    </div>

                </form>
            </div>
          </div>   
        
        <div class="row">
            <div class="medium-8 small-centered columns">
                <h2 class="subheader">Registrar retirada de livro</h2>
                </div> 
        </div>   
        
          <div class="row">    
           <div class="small-8 small-centered columns green">
                <form  name="contatof" method="post" action=" ">
                    <div class="row"> 
                        <div class="large-12 columns"> 
                            <label>
                                Titulo do livro: <input type="text" name="titulo" placeholder=" ex o tempo e o vento" />
                            </label>
                        </div> 
                    </div> 
                    <div class="row"> 
                        <div class="large-12 columns"> 
                            <label>
                                Código do livro: <input type="text" name="codigo" placeholder="codigo exemplo 123 " />
                            </label>
                        </div> 
                    </div> 
                    <div class="row"> 
                        <div class="large-12 columns"> 
                            <label>
                                Periodo:  <input type="text" name="periodo" placeholder="duração" />
                            </label>
                        </div> 
                    </div> 
                    <div class="row"> 
                    <div class="large-12 columns"> 
                            <label>
                                Matrícula:  <input type="text" name="matricula2" placeholder="Sua matrícula de 9 digitos" />
                            </label>
                        </div> 
                    </div> 
                    <div class="row"> 
                        <div class="large-12 columns">
                            <input type="submit"   name="aviso" value="Registrar retirada" />
                        </div>
                    </div>
                    
                    <div class="row"> 
                        <div class="large-12 columns">
                            <?php
                            if (isset($_POST['aviso'])) {
                                $matricula = filter_input(INPUT_POST, "matricula2", FILTER_SANITIZE_MAGIC_QUOTES);

                                if (buscaEmail($matricula) == true) {
                                $titulo = filter_input(INPUT_POST, "titulo", FILTER_SANITIZE_MAGIC_QUOTES);
                                $codigo = filter_input(INPUT_POST, "codigo", FILTER_SANITIZE_MAGIC_QUOTES);
                                $periodo = filter_input(INPUT_POST, "periodo", FILTER_SANITIZE_MAGIC_QUOTES);
                                
                                cadRetirada($titulo, $codigo, $periodo, $matricula);
                                
                                } //fim if tem email
                                else {
                                    echo "Se não está registrado, registre-se. É rápido e fácil!";
                                }
                                
                            }// fim isset
                            ?>
                        </div>
                    </div>

                </form>
            </div>
            
        </div>



        <!-- body content here -->

        <script src="js/vendor/jquery.js"></script>
        <script src="js/foundation.min.js"></script>
        <script>
            $(document).foundation();
        </script>
    </body>
</html>
