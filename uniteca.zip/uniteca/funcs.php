
<?php

include("conexao.php");
include("enviaEmail.php");
include("datas.php");


function listarPendencias($matricula) {
    $pdo = conectar();
    $busca = $pdo->prepare("SELECT matricula,codigo,titulo,dtinicio,dtentrega FROM alertas WHERE matricula = $matricula ");
    $busca->execute();
//return $busca->rowCount();
    $mostrar = $busca->fetchAll(PDO::FETCH_OBJ);
    return $mostrar;
}
//listarpendencias

function listarUsuario($matricula) {
    $pdo = conectar();
    $busca = $pdo->prepare("SELECT matricula,nome,email FROM usuarios WHERE matricula = $matricula ");
    $busca->execute();
//return $busca->rowCount();
    $mostrar = $busca->fetchAll(PDO::FETCH_OBJ);
    return $mostrar;
}
//listarUsuarios

function cadUser($nome, $matricula, $email) {
    $pdo = conectar();
    $buscasegura = $pdo->prepare('INSERT INTO usuarios(nome,matricula, email) VALUES (:nome,:matricula,:email) ');
    $buscasegura->bindValue(":nome", $nome);
    $buscasegura->bindValue(":matricula", $matricula);
    $buscasegura->bindValue(":email", $email);
    $validar = $pdo->prepare("SELECT *FROM usuarios WHERE matricula = ?");
    $validar->execute(array($matricula));
    if ($validar->rowCount() == 0) {
        $buscasegura->execute();
         enviar($email, 'Cadastro de usuário', 'Você se cadastrou no sistema de alertas de devoluções de livros.');

        echo "Cadastrado com sucesso!";
    } else {
        echo "já existe essa matricula";
    }
}
// cadUser

function cadRetirada($titulo, $codigo, $periodo, $matricula) {
    if ($matricula != null) {
    $pdo = conectar();
    $buscasegura = $pdo->prepare('INSERT INTO alertas(titulo, codigo, periodo, matricula, dtinicio, dtaviso, dtentrega) VALUES (:titulo, :codigo, :periodo, :matricula, :dtinicio, :dtaviso, :dtentrega) ');
    $buscasegura->bindValue(":titulo", $titulo);
    $buscasegura->bindValue(":codigo", $codigo);
    $buscasegura->bindValue(":periodo", $periodo);
    $buscasegura->bindValue(":matricula", $matricula);
    $buscasegura->bindValue(":dtinicio", date("y-m-d"));
    
    $dataEntreg =  addDias(($periodo), date("y-m-d"));
    $dataEntreg = diasUteis($dataEntreg);
    
    $buscasegura->bindValue(":dtaviso", dimDias(1, $dataEntreg));
    //addDias aumenta uma data em $paramsDias
    $buscasegura->bindValue(":dtentrega", $dataEntreg);

    // ADICIONAR as contagens das datas
    $buscasegura->execute();
   // buscaEmail($matricula);
    echo "Você será lembrado por email";
    }  // fim if matricula 
    
}
// fim cadr

function enviarAvisos() {
   $hoje = Date("y-m-d");
    $pdo = conectar();
   // Esta parte é responsável por  por verificar criterios para o envio de emails
    $buscaMat = $pdo->prepare("SELECT matricula FROM alertas WHERE dtaviso = '$hoje' ");
    // pega a matricula do alert
    //$busc            Parte responsável pela execução da query
    $buscaMat->execute();
    $mostrarMat = $buscaMat->fetchAll(PDO::FETCH_OBJ);
    //formata
    foreach ($mostrarMat as $tabela) {
        
        $mat = $tabela->matricula;
        $buscaEM = $pdo->prepare("SELECT email FROM usuarios WHERE matricula = $mat ");
         $buscaEM->execute();
        $mostrarEM = $buscaEM->fetch(PDO::FETCH_ASSOC);
        if ($mostrarEM != NULL ) {
            // envia os emails
       enviar($mostrarEM['email'], "Teste do sistema", "estou testando o sistema esta é uma mensagem automática");
            
       echo " / email : ".$mostrarEM['email']."</br>";
        } else {
            echo 'nulo :) nenhum email';
        }
      // var_dump($mostrarEM);
    }
}
//enviaravisos

function buscaEmail($matricula) {

    $pdo = conectar();
    // Esta parte é responsável por  por verificar criterios para o envio de emails
   // $buscaMat = $pdo->prepare("SELECT matricula FROM usuarios WHERE matricula = $matricula");
    // pega a matricula do alert
    //$busc            Parte responsável pela execução da query
   /// $buscaMat->execute();

   // $mostrarMat = $buscaMat->fetch(PDO::FETCH_OBJ);
    //formata        

        $buscaEM = $pdo->prepare("SELECT email FROM usuarios WHERE matricula = $matricula ");
        $buscaEM->execute();
        if ($buscaEM != null) {
        $mostrarEM = $buscaEM->fetch(PDO::FETCH_ASSOC);
        if ($mostrarEM != NULL) {
            // envia os emails
            enviar($mostrarEM['email'], 'Novo livro retirado', 'Você acaba de retirar um livro na 
                                        véspera da entrega você vai receber um aviso.');

            return true;
        } else {
            echo 'nenhum usuário encontrado';
            return false;
        }
        // fim
    } //fim buscamat
    else {return false; }
}
//buscarEmail

function contarAlertas() {
$hoje = Date("y-m-d");
$pdo = conectar();
$busca = $pdo->prepare("SELECT codigo FROM alertas WHERE dtaviso = '$hoje' ");
$busca->execute();
$numLinhas = $busca->rowCount();
//return $busca->rowCount();
return $numLinhas;


}
//buscarEmail();

function diasUteis($date) {

    $current_date = new DateTime($date);
    //criação de uma query com pdo para manipulaçã dos feriados
    $feriado1 = '2014-08-11'; //dia interacional da logosofoa
    
    if ($current_date->format('N') == 6) {
        $current_date->add(new DateInterval('P2D'));
         return diasUteis($current_date->format('Y-m-d'));

        //echo 'sabado';
    } else if ($current_date->format('N') == 7) {
        $current_date->add(new DateInterval('P1D'));
         return diasUteis($current_date->format('Y-m-d'));
        //echo 'domingo';
    } else if ($current_date->format('y-m-d') == $feriado1) {
        $current_date->add(new DateInterval('P1D'));
         return diasUteis($current_date->format('Y-m-d'));
        //echo 'feriado';
    }
    else {
        return $date;
    }
    
}
//dias Uteis


?>
