
<?php

$emailsender = 'no-reply01@kmobile.zz.mu';

$quebra_linha = "\n";

// Passando os dados obtidos pelo formulário para as variáveis abaixo
$nomeremetente = "testador";
$emailremetente = "php@kmobile.zz.mu";
$destinatario = "deivid.rv@gmail.com";
$assunto = "testando";
$mensagem = "mensagem enviada para teste";

function enviar( $destinatario, $assunto, $mensagem) {
    
    $emailremetente = "php@kmobile.zz.mu";
    $emailsender = 'no-reply01@kmobile.zz.mu';
    /* Montando a mensagem a ser enviada no corpo do e-mail. */
    $mensagemHTML = '<P>Olá esta é uma mensagem automática do sistema Uniteca</P>
     <P>Obrigado por utilizar nosso sistema</P>
     <P>Recomendamos que marque esta mensagem como "importante"</P>
      <p><b><i>' . $mensagem . '</i></b></p>
       <P> Sistema Uniteca</P>

     <hr>';
    

    /* Montando o cabeÃ§alho da mensagem */
    $headers = "MIME-Version: 1.1" . "\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1" . "\n";
// Perceba que a linha acima contém "text/html", sem essa linha, a mensagem não chegará formatada.
    $headers .= "From: " . $emailsender . "\n";
    $headers .= "Reply-To: " . $emailremetente . "\n";

    /* Enviando a mensagem */

    mail($destinatario, $assunto, $mensagemHTML, $headers);
}


?>

