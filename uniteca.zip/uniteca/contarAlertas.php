
<?php
include("funcs.php");

/*
function contarAlertas() {
$hoje = Date("y-m-d");
$pdo = conectar();
$busca = $pdo->prepare("SELECT dtentrega FROM alertas WHERE dtaviso = $hoje ");
$busca->execute();
$numLinhas = $busca->rowCount();
//return $busca->rowCount();
return $numLinhas;

}
 * 
 */
if (contarAlertas() > 0) {
    echo "foi";
   // buscarEmail();
  enviarAvisos();

}

?>
