<?php

// $nick = $_GET["nick"];
// $nome = $_GET["nome"];

$host = "localhost";
$user = "root";
$pass = "";
//$dbname = "teste";

function conectar() {
    try {
        $pdo = new PDO('mysql:host=mysql.hostinger.com.br;dbname=u445301973_uni', "u445301973_deiv","b1b2b3b4");
        //$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        // echo $buscasegura->rowCount();
    } catch (PDOOException $ex) {
        echo $ex->getMessage();
    }
    return $pdo;
}

// fim conectar
?>
