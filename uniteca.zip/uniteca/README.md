# uniteca
É um sistema para bibliotecas onde ele envia emails automáticos avisando que é necessário devolver os livros.
