
<?php
include("funcs.php");
?>

<!DOCTYPE html>
<!--[if IE 9]><html class="lt-ie10" lang="en" > <![endif]-->
<html class="no-js" lang="en" >

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Foundation 5</title>

        <!-- If you are using CSS version, only link these 2 files, you may add app.css to use for your overrides if you like. -->
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/foundation.css">

        <!-- If you are using the gem version, you need this only -->
        <link rel="stylesheet" href="css/app.css">

        <script src="js/vendor/modernizr.js"></script>
        <style>

        </style>

    </head>
    <body>

        <div class="row"> 
            <div class="large-12 columns"> 
                <nav class="top-bar" data-topbar> 
                    <ul class="title-area">
                        <li class="name">
                            <h1><a href="index.php">Página inicial </a></h1>
                        </li> 
                        <!-- Remove the class "menu-icon" to get rid of menu icon. Take out "Menu" to just have icon alone --> 
                        <li class="toggle-topbar menu-icon">
                            <a href="index.php"><span>Menu</span>
                            </a>
                        </li> 
                    </ul>
                    <section class="top-bar-section"> 

                        <!-- Left Nav Section -->
                        <ul class="left"> 
                            <li>
                                <a href="registro.php">Registrar usuário ou retiradas</a>
                            </li> 

                        </ul>
                        <ul class="left"> 
                            <li class = "active">
                                <a href=" ">Verificar pendências</a>
                            </li> 
                        </ul>
                    </section>
                </nav>
            </div> 
        </div> 
        <!--termin o menu-->

        <div class="row">
            <div class="medium-12 columns green">

                <form action =" "  method = "POST"> 
                    <div class="row"> 
                        </br>
                    </div> 
                    <div class="row">
                        <div class="large-8 small-centered  columns ">
                            <div class="row collapse">
                                <div class="small-8 columns"> 
                                    <input type="text" name ="matricula" placeholder="Digite sua matrícula"> 
                                </div> 
                                <div class="small-4 columns">
                                   <!-- <imput type="submit"  name ="ok" class="button postfix">Buscar registros  -->
                                    <input class="button postfix" type="submit" value="Buscar registros " name= "ok" />                                       
                                </div>
                            </div>
                        </div>

                    </div> 
                </form>

            </div>

        </div>

        <?php
        $matricula = "";
        if (isset($_POST['ok'])) {
            $matricula = filter_input(INPUT_POST, "matricula", FILTER_SANITIZE_MAGIC_QUOTES);
            //echo listarPendencias($matricula);
        } 
        ?>

        <!-- começa a tabela-->
        <div class="row">
            <div class="medium-12 columns green">
                <table> 
                    <thead> 
                        <tr> 
                            <th width="200">Matricula do aluno</th>
                            <th>Ttulo do livro</th>
                            <th width="150">Código do livro</th> 
                            <th width="150">Data de retirada</th> 
                            <th width="150">Data limite para entrega </th> 
                        </tr> 
                    </thead>
                    <tbody>
<?php
$teste = listarPendencias($matricula);

foreach ($teste as $tabela) :
?>
                            <tr> 
                                <td><?php echo $tabela->matricula; ?></td> 
                                <td><?php echo $tabela->titulo; ?></td> 
                                <td> <?php echo $tabela->codigo; ?></td>
                                <td><?php echo $tabela->dtinicio; ?></td>
                                <td><?php echo $tabela->dtentrega; ?></td>
                            </tr> 

<?php
endforeach;
if (Count($teste) == 0) {
     if (isset($_POST['ok'])){
    echo "Não foram encontrads registros! ";
     }
}
?>

                        <!-- loop -->

                    </tbody>
                </table>

            </div>

        </div>

        <!-- fim da tabela -->
        
        <!-- cmeçaa pequisa por usuarios -->

        <div class="row">
            <div class="medium-12 columns green">

                <form action =" "  method = "POST"> 
                    <div class="row"> 
                        </br>
                    </div> 
                    <div class="row">
                        <div class="large-8 small-centered  columns ">
                            <div class="row collapse">
                                <div class="small-8 columns"> 
                                    <input type="text" name ="matricula2" placeholder="Digite sua matrícula para buscar "> 
                                </div> 
                                <div class="small-4 columns">
                                   <!-- <imput type="submit"  name ="ok" class="button postfix">Buscar registros  -->
                                    <input class="button postfix" type="submit" value="Buscar usuários " name= "user" />                                       
                                </div>
                            </div>
                        </div>

                    </div> 
                </form>

            </div>

        </div>

        <?php
        
        $matricula2 = "";
        if (isset($_POST['user'])) {
            $matricula2 = filter_input(INPUT_POST, "matricula2", FILTER_SANITIZE_MAGIC_QUOTES);
            //echo listarPendencias($matricula);
        } 

        ?>

        <!-- começa a tabela-->
        <div class="row">
            <div class="medium-12 columns green">
                <table> 
                    <thead> 
                        <tr> 
                            <th width="200">Matricula do aluno</th>
                            <th>Nome completo </th>
                            <th width="150">email </th> 

                        </tr> 
                    </thead>
                    <tbody>
<?php
$teste2 = listarUsuario($matricula2);

foreach ($teste2 as $tabela) :
?>
                            <tr> 
                                <td><?php echo $tabela->matricula; ?></td> 
                                <td><?php echo $tabela->nome; ?></td> 
                                <td> <?php echo $tabela->email; ?></td>

                            </tr> 

<?php
endforeach;
if (Count($teste2) == 0) {
    if (isset($_POST['user'])){
    echo "usuário não encontrado!";
}
}
?>

                        <!-- loop -->

                    </tbody>
                </table>

            </div>

        </div>

        <!-- fim da tabela -->

        <script src="js/vendor/jquery.js"></script>
        <script src="js/foundation.min.js"></script>
        <script>
            $(document).foundation();
        </script>
    </body>
</html>

