<?php

/*
date_default_timezone_set('America/Sao_Paulo');
 
$inicio = '07/05/2013 02:12:27';
$fim = '07/07/2013 19:36:45';
 
// Converte as datas para objetos DateTime do PHP
// PARA O PHP 5.3 OU SUPERIOR
$inicio = DateTime::createFromFormat('d/m/Y H:i:s', $inicio);
 
//PARA O PHP 5.2
// $inicio = date_create_from_format('d/m/Y H:i:s', $inicio);
 
$fim = DateTime::createFromFormat('d/m/Y H:i:s', $fim);
// $fim = date_create_from_format('d/m/Y H:i:s', $fim);
 
// Calcula a diferença entre as duas datas
$intervalo = $inicio->diff($fim);
 
// Imprime a diferença entre as duas
// datas de modo formatado
print $intervalo->format(
    'A diferença entre as datas é de %Y ano(s), %M mese(s),
    %D dia(s), %H hora(s), %I minuto(s) e %S segundo(s).
    No geral, é um pouco mais de %a dias.');

*/



function addDias($num, $date) {
   $dataf = date('Y-m-d', strtotime($date. ' + '.$num.' days'));
    return $dataf;
}

function dimDias($num, $date) {
   $dataf = date('Y-m-d', strtotime($date. ' - '.$num.' days'));
    return $dataf;
}

$currentDate = date("Y-m-d");


//echo addDias(1,"2010-09-17");



?>